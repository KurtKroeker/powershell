# TODO: add parameters
# TODO: act upon parameters
# TODO: not necessary to always name params

# param(
# 	$param1,
# 	$param2
# )

# if($param1 -eq "foo"){
# 	"Hey, you must be a developer!"
# }

# Write-Host "$param1 $param2" -ForegroundColor Magenta

Write-Host "Hello, Techbash!"